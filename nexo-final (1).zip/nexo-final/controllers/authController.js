const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("../models/User");

const register = async (req, res) => {
  try {
    const { username, password, role, email, name } = req.body;

    if (!username || !password || !role) {
      return res.status(400).json({ error: "username, password and role are required." });
    }

    const existing = await User.findOne({ where: { username } });
    if (existing) {
      return res.status(400).json({ error: "Signup failed. User already exists." });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    await User.create({ username, password: hashedPassword, role, email, name });

    console.log(`👤 New User Registered: ${username} [${role}]`);
    res.json({ message: "Account created successfully!" });
  } catch (err) {
    console.error("Register error:", err.message);
    res.status(500).json({ error: err.message });
  }
};

const login = async (req, res) => {
  try {
    const { username, password, role } = req.body;

    if (!username || !password || !role) {
      return res.status(400).json({ error: "username, password and role are required." });
    }

    const user = await User.findOne({ where: { username, role } });
    if (!user) {
      return res.status(401).json({ error: "Invalid credentials or role selected." });
    }

    const match = await bcrypt.compare(password, user.password);
    if (!match) {
      return res.status(401).json({ error: "Invalid credentials or role selected." });
    }

    const token = jwt.sign(
      { id: user.id, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: "7d" }
    );

    console.log(`✅ Login: ${username} [${role}]`);
    res.json({
      message: "Login successful!",
      token,
      role: user.role,
    });
  } catch (err) {
    console.error("Login error:", err.message);
    res.status(500).json({ error: err.message });
  }
};

module.exports = { register, login };
