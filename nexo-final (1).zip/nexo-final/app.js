require("dotenv").config();
const express = require("express");
const cors = require("cors");
const twilio = require("twilio");
const sequelize = require("./config/db");
const authRoutes = require("./routes/authRoutes");

// ─── TWILIO CLIENT ─────────────────────────────────────────────────────────────
const client = twilio(
  process.env.TWILIO_ACCOUNT_SID,
  process.env.TWILIO_AUTH_TOKEN
);

// Validate required env vars at startup
const requiredEnv = [
  "TWILIO_ACCOUNT_SID",
  "TWILIO_AUTH_TOKEN",
  "TWILIO_WHATSAPP_NUMBER",
  "DB_URL",
  "JWT_SECRET",
];
requiredEnv.forEach((key) => {
  if (!process.env[key]) {
    console.error(`❌ Missing environment variable: ${key}`);
    process.exit(1);
  }
});

// ─── APP SETUP ────────────────────────────────────────────────────────────────
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(cors());
app.use(express.static("./"));

// ─── DATABASE AUTH ROUTES (/register and /login with Railway PostgreSQL) ───────
app.use("/", authRoutes);

// ─── OTP STORE  { phone: { code, expiresAt } } ────────────────────────────────
const otpStore = {};
const OTP_TTL_MS = 5 * 60 * 1000; // 5 minutes

// ─── RATE LIMITER ─────────────────────────────────────────────────────────────
const lastSentAt = {};
const RATE_LIMIT_MS = 60 * 1000; // 1 minute cooldown

// ─── HELPER ───────────────────────────────────────────────────────────────────
function isValidPhone(phone) {
  return /^\+\d{7,15}$/.test(phone);
}

// =============================================================================
//  WHATSAPP OTP ROUTES
// =============================================================================

// ─── SEND OTP ─────────────────────────────────────────────────────────────────
app.post("/send-otp", async (req, res) => {
  const { phone } = req.body;

  if (!phone || !isValidPhone(phone)) {
    return res.status(400).json({
      error: "Invalid phone number. Use international format e.g. +919876543210",
    });
  }

  const now = Date.now();
  if (lastSentAt[phone] && now - lastSentAt[phone] < RATE_LIMIT_MS) {
    const wait = Math.ceil((RATE_LIMIT_MS - (now - lastSentAt[phone])) / 1000);
    return res.status(429).json({
      error: `Please wait ${wait}s before requesting another OTP.`,
    });
  }

  const otp = Math.floor(100000 + Math.random() * 900000).toString();

  otpStore[phone] = {
    code: otp,
    expiresAt: now + OTP_TTL_MS,
  };
  lastSentAt[phone] = now;

  try {
    const message = await client.messages.create({
      body: `🔐 Your Nexo OTP is: *${otp}*\n\nThis code expires in 5 minutes. Do not share it with anyone.`,
      from: process.env.TWILIO_WHATSAPP_NUMBER.startsWith("whatsapp:")
        ? process.env.TWILIO_WHATSAPP_NUMBER
        : `whatsapp:${process.env.TWILIO_WHATSAPP_NUMBER}`,
      to: `whatsapp:${phone}`,
    });

    console.log(`📲 OTP sent to ${phone} | SID: ${message.sid}`);
    res.json({ message: "OTP sent successfully via WhatsApp!" });
  } catch (err) {
    console.error("❌ Twilio Error:", err.message);

    delete otpStore[phone];
    delete lastSentAt[phone];

    if (err.code === 63007) {
      return res.status(500).json({
        error:
          "WhatsApp not enabled. Send 'join <your-keyword>' to +14155238886 on WhatsApp first.",
      });
    }

    res.status(500).json({ error: `Failed to send OTP: ${err.message}` });
  }
});

// ─── VERIFY OTP ───────────────────────────────────────────────────────────────
app.post("/verify-otp", (req, res) => {
  const { phone, otp } = req.body;

  if (!phone || !otp) {
    return res.status(400).json({ error: "Phone and OTP are required." });
  }

  const record = otpStore[phone];

  if (!record) {
    return res
      .status(400)
      .json({ error: "No OTP found for this number. Please request a new one." });
  }

  if (Date.now() > record.expiresAt) {
    delete otpStore[phone];
    return res
      .status(400)
      .json({ error: "OTP has expired. Please request a new one." });
  }

  if (record.code !== otp.trim()) {
    return res.status(400).json({ error: "Incorrect OTP. Please try again." });
  }

  delete otpStore[phone];
  console.log(`✅ WhatsApp OTP verified for ${phone}`);

  res.json({
    message: "Login successful!",
    token: "mock-jwt-token",
    role: "student",
  });
});

// =============================================================================
//  START SERVER (after DB connects)
// =============================================================================
sequelize
  .sync()
  .then(() => {
    console.log("✅ Railway PostgreSQL database connected & synced");
    app.listen(PORT, () => {
      console.log(`\n🚀 Nexo server running at http://localhost:${PORT}`);
      console.log(`📲 WhatsApp OTP via: ${process.env.TWILIO_WHATSAPP_NUMBER}`);
      console.log(`🗄️  Database: Railway PostgreSQL\n`);
      console.log(`📖 Open http://localhost:${PORT}/homepage.html to start\n`);
    });
  })
  .catch((err) => {
    console.error("❌ Database connection failed:", err.message);
    process.exit(1);
  });
